#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  1 18:00:29 2019

@author: angelawu
"""

# =============================================================================
# TODO: implement ANF method: https://arxiv.org/pdf/1708.07136.pdf
# =============================================================================
