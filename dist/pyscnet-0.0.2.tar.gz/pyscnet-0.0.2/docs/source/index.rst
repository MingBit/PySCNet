.. pyscnet documentation master file, created by
   sphinx-quickstart on Thu Jul 16 11:16:58 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyscnet's documentation!
===================================

.. toctree::
   :maxdepth: 2

   :caption: Contents:

   ../../README
   pyscnet_installation
   pyscnet_api
   pyscnet_tutorial

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
